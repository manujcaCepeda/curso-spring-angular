package com.manu;

import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public class Ejemplo_1 {

	public static void main(String[] args) {
		
//		ejemplo de Predicate
		Predicate<String> examplePredicate = (s) -> s.length() < 10;
		System.out.println(examplePredicate.test("hola mundo"));
		
//		ejemplo de Consumer
		Consumer<String> exampleConsumer = (s) -> {
			System.out.println(s.toLowerCase());
			System.out.println(s.toUpperCase());
		};
		exampleConsumer.accept("asasasAAAAAUKVBG");
		
//		ejemplo de Function
		Function<Integer, String> exampleFunction = (num) -> Integer.toString(num);
		System.out.println(exampleFunction.apply(26).length());
		
//		ejemplo de Supplier
		Supplier<String> exampleSupplier = () -> "Java es divertido";
		System.out.println(exampleSupplier.get());
		
//		ejemplo Operador Binario
		BinaryOperator<Integer> add = (a, b) -> a + b;
		System.out.println("suma: " + add.apply(10, 25));
		
//		ejemplo Operador Unary
		UnaryOperator<String> str = (mensaje) -> mensaje.toUpperCase();
		System.out.println(str.apply("Este es un mensaje"));
	}

}
