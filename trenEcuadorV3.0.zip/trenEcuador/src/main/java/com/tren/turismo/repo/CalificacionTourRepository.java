package com.tren.turismo.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.tren.turismo.modelo.CalificacionTour;
import com.tren.turismo.modelo.CalificacionTourPk;

public interface CalificacionTourRepository extends CrudRepository<CalificacionTour, CalificacionTourPk>{
	
	
	List<CalificacionTour> findByPkTourId(Integer tourId);
	
	//CalificacionTour findByPkTourIdAndClienteId(Integer tourId, Integer clienteId);


}
