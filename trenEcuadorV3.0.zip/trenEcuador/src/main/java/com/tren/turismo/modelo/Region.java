package com.tren.turismo.modelo;

public enum Region {
	Region_Costa("Costa"), Region_Sierra("Sierra"), Region_Amazonia("Amazonia");
	
	private String label;

	private Region(String label) {
		this.label = label;
	}
	
	public static Region findByLabel(String label) {
		for(Region region : Region.values()) {
			if(region.label.equals(label)) {
				return region;
			}
		}
		return null;
	}
	
}
