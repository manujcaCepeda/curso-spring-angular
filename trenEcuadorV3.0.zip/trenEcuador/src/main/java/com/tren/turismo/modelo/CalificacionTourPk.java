package com.tren.turismo.modelo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;

@Embeddable
public class CalificacionTourPk implements Serializable{

	@ManyToOne
	private Tour tour;
	
	@Column(insertable=false, updatable=false, nullable=false)
	private Integer clienteId;

	public CalificacionTourPk(){
		
	}
	
	public CalificacionTourPk(Tour tour, Integer clienteId) {
		super();
		this.tour = tour;
		this.clienteId = clienteId;
	}

	/**
	 * @return the tour
	 */
	public Tour getTour() {
		return tour;
	}

	/**
	 * @param tour the tour to set
	 */
	public void setTour(Tour tour) {
		this.tour = tour;
	}

	/**
	 * @return the clienteId
	 */
	public Integer getClienteId() {
		return clienteId;
	}

	/**
	 * @param clienteId the clienteId to set
	 */
	public void setClienteId(Integer clienteId) {
		this.clienteId = clienteId;
	}
	
}
