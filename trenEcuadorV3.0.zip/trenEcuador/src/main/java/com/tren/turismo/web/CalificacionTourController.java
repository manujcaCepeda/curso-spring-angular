package com.tren.turismo.web;

import java.util.NoSuchElementException;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.tren.turismo.dto.CalificacionDto;
import com.tren.turismo.modelo.CalificacionTour;
import com.tren.turismo.modelo.CalificacionTourPk;
import com.tren.turismo.modelo.Tour;
import com.tren.turismo.repo.CalificacionTourRepository;
import com.tren.turismo.repo.TourRepository;

@RestController
@RequestMapping(path = "/tours/{tourId}/calificaciones")
public class CalificacionTourController {

	CalificacionTourRepository calificacionTourRepository;

	TourRepository tourRepository;

	public CalificacionTourController() {

	}

	@Autowired
	public CalificacionTourController(CalificacionTourRepository calificacionTourRepository,
			TourRepository tourRepository) {
		super();
		this.calificacionTourRepository = calificacionTourRepository;
		this.tourRepository = tourRepository;
	}

	@RequestMapping(method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public void createCalificacionTour(@PathParam(value = "tourId") Integer tourId, @RequestBody @Validated CalificacionDto dto) {
		Tour tour = verificarTour(tourId);
		calificacionTourRepository.save(new CalificacionTour(new CalificacionTourPk(tour, dto.getClienteId()), dto.getPuntuacion(), dto.getComentario()));

	}

	public Tour verificarTour(Integer tourId) {
		Tour tour = tourRepository.findOne(tourId);
		if (tour == null) {
			throw new NoSuchElementException("Tour no existe: " + tourId);
		}
		return tour;
	}

}
