package com.tren.turismo.modelo;

public enum Dificultad {
	Facil, Medio, Dificil;
}
