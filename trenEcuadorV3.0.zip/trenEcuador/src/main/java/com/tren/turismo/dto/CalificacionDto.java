package com.tren.turismo.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CalificacionDto {

	@Min(0)
	@Max(5)
	private Integer puntuacion;
	
	@Size(max=255)
	private String comentario;
	
	@NotNull
	private Integer clienteId;

	public CalificacionDto(){
		
	}
	
	public CalificacionDto(Integer puntuacion, String comentario, Integer clienteId) {
		super();
		this.puntuacion = puntuacion;
		this.comentario = comentario;
		this.clienteId = clienteId;
	}

	/**
	 * @return the puntuacion
	 */
	public Integer getPuntuacion() {
		return puntuacion;
	}

	/**
	 * @param puntuacion the puntuacion to set
	 */
	public void setPuntuacion(Integer puntuacion) {
		this.puntuacion = puntuacion;
	}

	/**
	 * @return the comentario
	 */
	public String getComentario() {
		return comentario;
	}

	/**
	 * @param comentario the comentario to set
	 */
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	/**
	 * @return the clienteId
	 */
	public Integer getClienteId() {
		return clienteId;
	}

	/**
	 * @param clienteId the clienteId to set
	 */
	public void setClienteId(Integer clienteId) {
		this.clienteId = clienteId;
	}
	
	
}
