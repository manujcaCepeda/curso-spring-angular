package com.tren.turismo.servicios;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tren.turismo.modelo.Dificultad;
import com.tren.turismo.modelo.Paquete;
import com.tren.turismo.modelo.Region;
import com.tren.turismo.modelo.Tour;
import com.tren.turismo.repo.PaqueteRepository;
import com.tren.turismo.repo.TourRepository;

@Service
public class TourServicio {

	TourRepository tourRepository;
	PaqueteRepository paqueteRepository;

	@Autowired	
	public TourServicio(TourRepository tourRepository, PaqueteRepository paqueteRepository) {
		super();
		this.tourRepository = tourRepository;
		this.paqueteRepository = paqueteRepository;
	}

	public Tour create(String titulo, String descripcion, double precio, String duracion, String keywords, 
			String codigoPaquete, Dificultad dificultad, Region region) {
		
		Paquete paquete = paqueteRepository.findOne(codigoPaquete);
		if(paquete == null) {
			throw new RuntimeException("Paquete no existe " + codigoPaquete);
		}
		return tourRepository.save(new Tour(titulo, descripcion, precio, duracion, keywords, paquete));
	}
	
	public Iterable<Tour> findAll(){
		return tourRepository.findAll();
	}
	
	public long count() {
		return tourRepository.count();
	}
	
}
