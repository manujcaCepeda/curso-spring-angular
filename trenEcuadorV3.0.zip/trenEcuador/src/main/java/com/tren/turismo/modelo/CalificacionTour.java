package com.tren.turismo.modelo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class CalificacionTour implements Serializable{

	@EmbeddedId
	private CalificacionTourPk pk;
	
	@Column(nullable=false)
	private Integer puntuacion;
	
	private String comentario;
	
	public CalificacionTour(){
		
	}

	public CalificacionTour(CalificacionTourPk pk, Integer puntuacion, String comentario) {
		super();
		this.pk = pk;
		this.puntuacion = puntuacion;
		this.comentario = comentario;
	}

	/**
	 * @return the pk
	 */
	public CalificacionTourPk getPk() {
		return pk;
	}

	/**
	 * @param pk the pk to set
	 */
	public void setPk(CalificacionTourPk pk) {
		this.pk = pk;
	}

	/**
	 * @return the puntuacion
	 */
	public Integer getPuntuacion() {
		return puntuacion;
	}

	/**
	 * @param puntuacion the puntuacion to set
	 */
	public void setPuntuacion(Integer puntuacion) {
		this.puntuacion = puntuacion;
	}

	/**
	 * @return the comentario
	 */
	public String getComentario() {
		return comentario;
	}

	/**
	 * @param comentario the comentario to set
	 */
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	
	
}
