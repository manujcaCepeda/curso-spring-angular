package com.tren.turismo.servicios;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tren.turismo.modelo.Paquete;
import com.tren.turismo.repo.PaqueteRepository;

@Service
public class PaqueteServicio {

	PaqueteRepository paqueteRepository;

	@Autowired
	public PaqueteServicio(PaqueteRepository paqueteRepository) {
		super();
		this.paqueteRepository = paqueteRepository;
	}
	
	public Paquete create(String codigo, String nombre) {
		if(!paqueteRepository.exists(codigo)) {
			paqueteRepository.save(new Paquete(codigo, nombre));
		}
		return null;
	}
	
	public Iterable<Paquete> findAll(){
		return paqueteRepository.findAll();
	}
	
	public long count() {
		return paqueteRepository.count();
	}
	
}
