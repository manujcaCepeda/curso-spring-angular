package com.tren.turismo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrenEcuadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrenEcuadorApplication.class, args);
	}
}
