package com.tren.turismo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.tren.turismo.modelo.Dificultad;
import com.tren.turismo.modelo.Region;
import com.tren.turismo.servicios.PaqueteServicio;
import com.tren.turismo.servicios.TourServicio;

@SpringBootApplication
public class TrenEcuadorApplication implements CommandLineRunner {

	@Autowired
	TourServicio tourServicio;
	@Autowired
	PaqueteServicio paqueteServicio;
	
	
	public static void main(String[] args) {
		SpringApplication.run(TrenEcuadorApplication.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
		paqueteServicio.create("AP", "De los Andes al Pacífico");
		paqueteServicio.create("PA", "Del Pacífico a los Andes");
		paqueteServicio.create("AN", "Andes del Norte");
		paqueteServicio.create("AC", "Andes del Centrales");
		
		paqueteServicio.findAll().forEach(paquete -> System.out.println("paquete---------> " + paquete));
		
		tourServicio.create("Tren de las Maravillas", "El viaje inicia en los Andes del norte, en el valle de Otavalo donde alternan tradiciones culturales ancestrales y cultivos de exportación, como las rosas. Desde Quito iniciamos el viaje hacia la costa, ascendiendo primero a los páramos del Chimborazo a través de la Avenida de los Volcanes.", 
				1.650, "4 días – 4 noches", "Quito – Guayaquil", "AP", Dificultad.Medio, Region.Region_Sierra);
		tourServicio.create("Tren a las Nubes", "En este viaje a bordo del Tren Crucero ascenderemos 3600 metros en apenas 450 kilómetros, experimentando así uno de los cambios de vegetación y paisaje más impresionantes del mundo. De las fértiles llanuras de la costa ascendemos a las tierras altas de los Andes a través de la mítica Nariz del Diablo. Atravesando la Avenida de los Volcanes llegamos a Quito, Patrimonio de la Humanidad, para trasladarnos a Otavalo, en los Andes del Norte donde descubriremos la cultura y tradiciones de los quichua y las plantaciones de rosas de exportación. Al regreso le espera su última noche en un hotel en Quito.	", 
				1.650, "4 días – 4 noches", "Quito – Guayaquil", "PA", Dificultad.Dificil, Region.Region_Costa);
		
		tourServicio.findAll().forEach(tour -> System.out.println("tour---------> " + tour));
	}
}
