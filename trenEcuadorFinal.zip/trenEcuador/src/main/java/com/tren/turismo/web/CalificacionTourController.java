package com.tren.turismo.web;

import java.util.AbstractMap;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.tren.turismo.dto.CalificacionDto;
import com.tren.turismo.modelo.CalificacionTour;
import com.tren.turismo.modelo.CalificacionTourPk;
import com.tren.turismo.modelo.Tour;
import com.tren.turismo.repo.CalificacionTourRepository;
import com.tren.turismo.repo.TourRepository;

@RestController
@RequestMapping(path = "/tours/{tourId}/calificaciones")
public class CalificacionTourController {

	CalificacionTourRepository calificacionTourRepository;

	TourRepository tourRepository;

	public CalificacionTourController() {

	}

	@Autowired
	public CalificacionTourController(CalificacionTourRepository calificacionTourRepository,
			TourRepository tourRepository) {
		super();
		this.calificacionTourRepository = calificacionTourRepository;
		this.tourRepository = tourRepository;
	}

	@RequestMapping(method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public void createCalificacionTour(@PathVariable(value = "tourId") Integer tourId, @RequestBody @Validated CalificacionDto dto) {
		Tour tour = verificarTour(tourId);
		calificacionTourRepository.save(new CalificacionTour(new CalificacionTourPk(tour, dto.getClienteId()), dto.getPuntuacion(), dto.getComentario()));

	}

	public Tour verificarTour(Integer tourId) {
		Tour tour = tourRepository.findOne(tourId);
		if (tour == null) {
			throw new NoSuchElementException("Tour no existe: " + tourId);
		}
		return tour;
	}
	
	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(NoSuchElementException.class)
	public String return400(NoSuchElementException ex) {
		return ex.getMessage();
	}
	
	private CalificacionDto toDto(CalificacionTour calificacionTour) {
		return new CalificacionDto(calificacionTour.getPuntuacion(), calificacionTour.getComentario(), calificacionTour.getPk().getClienteId());
	}
	
//	@RequestMapping(method = RequestMethod.GET)
//	public List<CalificacionDto> getAllCalificacionesForTour(@PathVariable(value = "tourId") Integer tourId){
//		verificarTour(tourId);
//		return calificacionTourRepository.findByPkTourId(tourId).stream().map(califTour -> toDto(califTour)).collect(Collectors.toList());
//	}
	
	@RequestMapping(method = RequestMethod.GET, path="/promedio")
	public AbstractMap.SimpleEntry<String, Double> getPromedio(@PathVariable(value = "tourId") Integer tourId){
		verificarTour(tourId);
		List<CalificacionTour> lista = calificacionTourRepository.findByPkTourId(tourId);
		OptionalDouble promedio = lista.stream().mapToInt(CalificacionTour :: getPuntuacion).average();
		return new AbstractMap.SimpleEntry<String, Double>("promedio", promedio.isPresent()?promedio.getAsDouble(): null);
	}

	
	public CalificacionTour verificarCalificacionTour(Integer tourId, Integer clienteId) {
		CalificacionTour calificacionTour = calificacionTourRepository.findByPkTourIdAndPkClienteId(tourId, clienteId);
		if (calificacionTour == null) {
			throw new NoSuchElementException("Tour-Calificacion no existe: " + tourId + " para el cliente: " + clienteId);
		}
		return calificacionTour;
	}
	
	@RequestMapping(method = RequestMethod.PUT)
	public CalificacionDto actualizarCalificacionTour(@PathVariable(value = "tourId") Integer tourId, @RequestBody @Validated CalificacionDto dto) {
		CalificacionTour calificacionTour = verificarCalificacionTour(tourId, dto.getClienteId());
		calificacionTour.setPuntuacion(dto.getPuntuacion());
		calificacionTour.setComentario(dto.getComentario());
		
		return toDto(calificacionTourRepository.save(calificacionTour));
	}
	
	@RequestMapping(method = RequestMethod.PATCH)
	public CalificacionDto actualizarCalificacionTourPatch(@PathVariable(value = "tourId") Integer tourId, @RequestBody @Validated CalificacionDto dto) {
		CalificacionTour calificacionTour = verificarCalificacionTour(tourId, dto.getClienteId());
		if(dto.getPuntuacion() != null) {
			calificacionTour.setPuntuacion(dto.getPuntuacion());
		}
		if(dto.getComentario() != null) {
			calificacionTour.setComentario(dto.getComentario());
		}		
		return toDto(calificacionTourRepository.save(calificacionTour));
	}
	
	@RequestMapping(method = RequestMethod.DELETE, path="/{clienteId}")
	public void deleteCalificacionTour(@PathVariable(value = "tourId") Integer tourId, @PathVariable(value = "clienteId") Integer clienteId) {
		CalificacionTour calificacionTour = verificarCalificacionTour(tourId, clienteId);
		calificacionTourRepository.delete(calificacionTour);
	}
	
	
	
	
	
	
	@RequestMapping(method = RequestMethod.GET)
	public Page<CalificacionDto> getAllCalificacionesForTour(@PathVariable(value = "tourId") Integer tourId, Pageable pageable){
		verificarTour(tourId);
		Page<CalificacionTour> calificacionesTourPage = calificacionTourRepository.findByPkTourId(tourId, pageable);
		List<CalificacionDto> listaDto = calificacionesTourPage.getContent().stream().map(califTour -> toDto(califTour)).collect(Collectors.toList());
		return new PageImpl(listaDto, pageable, calificacionesTourPage.getTotalPages());
	}
}
