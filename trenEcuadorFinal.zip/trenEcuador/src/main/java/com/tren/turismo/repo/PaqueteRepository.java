package com.tren.turismo.repo;

import org.springframework.data.repository.CrudRepository;

import com.tren.turismo.modelo.Paquete;

public interface PaqueteRepository extends CrudRepository<Paquete, String>{

}
